KNN Project Document
----
+ Submission Files
  + source code pack
  + graphs that is used for parameter choosing

  ​

1. Experimental Result

   1. In the experiment, we choose 2 paramters, i.e. $$ K$$ , the number of neaerest neighbors and metric,  the way *distance* is defined, as our arguments of optimization. After cross validation, $$K \in \{3,5,7,...,29\}\ \ , metric \in \{Euclidean, Cityblock\} $$, i.e. 28 trails, we come to the followings:

      ​

      1. the optimized parameter is **$K=9\ \ metric=Cityblock$**

         1. For either default(Euclidean) or Cityblock metric, $\forall K_i , K_i\neq 9$ , $$err(K_i) > err(K=9)$$ 
         2. $err(K=9|citybock) =0.162 < 0.165=err(K=9|euclidean)$ 

         ![knn-demo-2cr10-trails](D:\Desktop\knnPrj\knnDemo-city.jpg)

      2. Using the optimized parameters **obtained, after trained by trainSet**, to classify the testSet's samples, feedback an error-sample ratio **$ err= 0.1676$**, which is **larger** than it on the trainSet session. It's acceptable, since in the cross validation sessions, **for every trail**, the ratio betwen training samples and predicted samples is $ \frac {9000} {1000}$ , while for the test session, the ration is $ \frac {10000} {5000} $. Intuitively, in the tuning part, we have more information to help in decision making, i.e., *we can averagely 'ask' 9 dots what will the next dot will do? While for test session, we can only turn to 2 dots for 'help*'. That can help convince us why the error rises, compared with that of the previous tuning session.

      ​

2. Way of improving performance

   The larger trainSet is, the more time-consuming Knn will be; distance-calculating is also crutial in term of performance. Hence we can improve the KNN performance in the following ways:

   1. **Concentrate** training samples, only if the training set is redundant. We may find a subset of the original training set, which brings us almost the same accuracy. For more in details, we may turn to  *Condensing algorithm*, *WilSon's Editing*, etc..
   2. Optimizing the way of distance defining. Let's say, if *definition A*, requires arduous calculation and consumes 10ms each time; while *definiton B*, a swift one, takes only 0.1ms. Assume our training process requires N (really large)repititions, then B takes 100 times more than A takes. Re-defining the distance, might help.

   ​

3. Details & Others

   1. source code package:

      + main.m <--knnDemo.m<--testGenrator.m
        + knnDemo.m: the file that defines a function *knnDemo(mode)*, which performs trainSet's tuning and feedbacks the *best* $$K$$.
        + main.m calls *knnDemo()* twice(*mode=0 for Euclidean, mode=1 for cityblock*), finish the cross validation and with the *'besk'* $K$, perform the ultimate classfication on the testSet.
        + testGenerator.m: the file that defines a function *testGenerator(sep, target, order)*, which generates test samples. training samples and training samples' coresponding labels for each loop. 
      + \*.fig/jpg is figures that may be refered to
      + knn-prj.md: original mardown doc of the report.

      ​





