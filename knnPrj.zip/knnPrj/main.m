load data.mat;
feaVec = trainSet.X;
labelVec = trainSet.Y;

kErrBuff=knnDemo(0,feaVec, labelVec);
kErrBuff=knnDemo(1, feaVec, labelVec);
[dummy, minPosition] = min(kErrBuff);
bestK = minPosition*2 + 1;

% parametrize k<-bestK, re-train with all trainSet data
testPredLabel = knnclassify( testSet.X', feaVec', labelVec',bestK,'cityblock');
testPredLabel = testPredLabel';
% statistc session
buffCompare = zeros(1, length(testPredLabel));
buffCompare(testPredLabel~=testSet.Y)=1; % mark those fails with '1'
err = find(buffCompare==1);
errRatio = length(err)/length(buffCompare)
