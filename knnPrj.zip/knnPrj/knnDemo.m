function [output] = knnDemo(mode, feaVec, labelVec)

% 10%-90% trainSet --> parameter training
divGrpNum = 10;
kMin = 3;
kMax = 29;
errBuff = zeros(1, divGrpNum);
kErrBuff = zeros(1, 1+(kMax-kMin)/2); % only odd numbers, thus /2
kDevBuff = zeros(1, 1+(kMax-kMin)/2); 
kount = 1;
for k = kMin:2:kMax
    for i = 1:1:divGrpNum
        [testSample, trainSample] = testGenerator(divGrpNum, feaVec, i);
        [testLabel, trainLabel] = testGenerator(divGrpNum, labelVec, i);
        % knn session
        if mode == 0
            predictLabel = knnclassify(testSample', trainSample', trainLabel',k);
        else
            predictLabel = knnclassify(testSample', trainSample', trainLabel',k,'cityblock');
        end
        predictLabel = predictLabel';
        buffCompare=zeros(1,length(testLabel));
        % mark those failed prediction with '1'
        buffCompare(predictLabel~=testLabel)=1;
        % statistic Session
             %%tabulate(buffCompare)
        err = find(buffCompare==1);
        errBuff(i) = length(err)/length(buffCompare);
    end
    
    kErrBuff(kount) = mean(errBuff);
    kDevBuff(kount) = var(errBuff);
    kount = kount + 1;
end

% data visualization
k = [kMin:2:kMax];
if mode == 0
    subplot(2,2,1);
    bar(k,kErrBuff);
    title('default Knn');
    xlabel('k');
    ylabel('error');
    subplot(2,2,2);
    bar(k,kDevBuff);
    title('default Knn');
    xlabel('k')
    ylabel('deviation');
else
    subplot(2,2,3);
    bar(k,kErrBuff);
    title('cityblock knn');
    xlabel('k');
    ylabel('error');
    subplot(2,2,4);
    bar(k,kDevBuff);
    title('cityblock Knn');
    xlabel('k')
    ylabel('deviation');
end
    output = kErrBuff;

end

