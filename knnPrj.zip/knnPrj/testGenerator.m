function [ testSample, trainSample ] = testGenerator(sep, target, order)
% testSet generated from the 10% trainSet
%   sep --> number of subsets
%   order --> which one is chosen
    targetSize = length(target);
    grpSize = fix(targetSize / sep);
    % the test set, which should behave as argument 'sample' of knnclass
    % eg:test set is the subset[1000i, 2000i]
    start = max(1, (order -1)*grpSize+1);
    terminal = min(targetSize, order*grpSize);
    testSample = target(:,start:terminal);
    
    % the train set, 90%, which should behave as argument 'train' of knn
    % eg: train set is the subset[1,1000i)U[2000i+1,N]
    buff = target(:,1:start-1);
    trainSample = target(:, terminal+1:targetSize);
    trainSample = [buff, trainSample];  

end

